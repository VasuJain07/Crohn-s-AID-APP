package com.camo.tbapp.di

import android.content.Context
import com.camo.tbapp.database.Repository
import com.camo.tbapp.database.remote.api.ApiService
import com.camo.tbapp.database.remote.api.PredictionApiHelper
import com.camo.tbapp.util.Constants
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object Module {

    @Singleton
    @Provides
    fun getRetrofit(): Retrofit {
        return Retrofit.Builder()
            .baseUrl(Constants.BASE_URL)
            .addConverterFactory(GsonConverterFactory.create())
            .build() // Doesn't require the adapter
    }

    @Provides
    @Singleton
    fun getCGService(): ApiService = getRetrofit().create(ApiService::class.java)

    @Provides
    @Singleton
    fun getCGApiHelper(): PredictionApiHelper = PredictionApiHelper(getCGService())

//    @Provides
//    @Singleton
//    fun getAppDb(@ApplicationContext context: Context): LocalAppDb = Room.databaseBuilder(
//        context.applicationContext,
//        LocalAppDb::class.java,
//        "appDB.db"
//    ).fallbackToDestructiveMigration().build()

    @Provides
    @Singleton
    fun getRepo(@ApplicationContext context: Context): Repository = Repository(getCGApiHelper())
}
