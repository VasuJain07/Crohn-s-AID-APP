package com.camo.tbapp.ui;

public class PatientInfo {
    String uhid, city, pname, pnum, dname, dnum, date;

    public PatientInfo ( ) {
    }

    public PatientInfo (String uhid, String city, String pname, String pnum, String dname, String dnum, String date) {
        this.uhid = uhid;
        this.city = city;
        this.pname = pname;
        this.pnum = pnum;
        this.dname = dname;
        this.dnum = dnum;
        this.date = date;
    }

    public String getUhid ( ) {
        return uhid;
    }

    public void setUhid (String uhid) {
        this.uhid = uhid;
    }

    public String getCity ( ) {
        return city;
    }

    public void setCity (String city) {
        this.city = city;
    }

    public String getPname ( ) {
        return pname;
    }

    public void setPname (String pname) {
        this.pname = pname;
    }

    public String getPnum ( ) {
        return pnum;
    }

    public void setPnum (String pnum) {
        this.pnum = pnum;
    }

    public String getDname ( ) {
        return dname;
    }

    public void setDname (String dname) {
        this.dname = dname;
    }

    public String getDnum ( ) {
        return dnum;
    }

    public void setDnum (String dnum) {
        this.dnum = dnum;
    }


    public String getDate ( ) {
        return date;
    }

    public void setDate (String date) {
        this.date = date;
    }

}
