package com.camo.tbapp.util

import android.content.Context
import android.content.SharedPreferences
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.os.Build
import timber.log.Timber

object ContextUtility {
    /**
     * Distinguishes different kinds of app starts:  *
     * First start ever ([.FIRST_TIME])
     * First start in this version ([.FIRST_TIME_VERSION])
     * Normal app start ([.NORMAL])
     * @author schnatterer
     */
    enum class AppStart {
        FIRST_TIME, FIRST_TIME_VERSION, NORMAL
    }

    /**
     * The app version code (not the version name!) that was used on the last
     * start of the app.
     */
    private const val LAST_APP_VERSION = "last_app_version"

    /**
     * Finds out started for the first time (ever or in the current version).<br></br>
     * <br></br>
     * Note: This method is **not idempotent** only the first call will
     * determine the proper result. Any subsequent calls will only return
     * [AppStart.NORMAL] until the app is started again. So you might want
     * to consider caching the result!
     *
     * @return the type of app start
     */
    fun checkAppStart(context: Context, sharedPreferences: SharedPreferences): AppStart? {
        val pInfo: PackageInfo

        var appStart: AppStart? = AppStart.NORMAL
        try {
            pInfo = context.packageManager.getPackageInfo(context.packageName, 0)
            val lastVersionCode = sharedPreferences
                .getLong(LAST_APP_VERSION, -1L)
            val currentVersionCode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                pInfo.longVersionCode
            } else {
                pInfo.versionCode.toLong()
            }
            appStart = checkAppStart(currentVersionCode, lastVersionCode)
            // Update version in preferences
            sharedPreferences.edit()
                .putLong(LAST_APP_VERSION, currentVersionCode).apply()
        } catch (e: PackageManager.NameNotFoundException) {
            Timber.w(
                "Unable to determine current app version from package manager. Defensively assuming normal app start."
            )
        }
        return appStart
    }

    private fun checkAppStart(currentLongVersionCode: Long, lastLongVersionCode: Long): AppStart {
        return when {
            lastLongVersionCode == -1L -> {
                AppStart.FIRST_TIME
            }
            lastLongVersionCode < currentLongVersionCode -> {
                AppStart.FIRST_TIME_VERSION
            }
            lastLongVersionCode > currentLongVersionCode -> {
                Timber.w(
                    "Current version code ($currentLongVersionCode) is less then the one recognized on last startup ($lastLongVersionCode). Defensively assuming normal app start."
                )
                AppStart.NORMAL
            }
            else -> {
                AppStart.NORMAL
            }
        }
    }
}
