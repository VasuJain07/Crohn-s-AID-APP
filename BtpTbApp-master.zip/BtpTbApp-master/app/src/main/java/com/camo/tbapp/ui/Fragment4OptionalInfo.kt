package com.camo.tbapp.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import androidx.core.widget.doAfterTextChanged
import androidx.core.widget.doOnTextChanged
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import com.camo.tbapp.R
import com.camo.tbapp.databinding.Fragment4OptionalInfoBinding
import com.camo.tbapp.ui.viewmodels.AddNewCaseActivityVM
import timber.log.Timber

class Fragment4OptionalInfo : Fragment() {
    private var _binding: Fragment4OptionalInfoBinding? = null

    // valid from onCreateView to onDestroy
    private val binding: Fragment4OptionalInfoBinding get() = _binding!!

    private val viewModel by activityViewModels<AddNewCaseActivityVM>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Timber.d("onCreate called")
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = Fragment4OptionalInfoBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val igraAdapter = ArrayAdapter(
            binding.root.context, R.layout.support_simple_spinner_dropdown_item,
            requireContext().resources.getTextArray(R.array.igra)
        )
        binding.spinnerIgra.setAdapter(igraAdapter)
        setUpListeners()
    }

    private fun setUpListeners() {
        binding.etvFox.doOnTextChanged { text, start, before, count ->
            viewModel.setFox((text ?: "").toString())
        }
        binding.etvVisceralFat.doAfterTextChanged {
            viewModel.setVisceralFat((it ?: "").toString())
        }
        binding.spinnerIgra.onItemClickListener =
            AdapterView.OnItemClickListener { parent, view, position, id ->
                viewModel.setIgra(position)
            }
    }

    override fun onDestroy() {
        super.onDestroy()
        _binding = null
    }
}
