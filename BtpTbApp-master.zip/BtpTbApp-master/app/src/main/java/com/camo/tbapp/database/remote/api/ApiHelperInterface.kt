package com.camo.tbapp.database.remote.api

import com.camo.tbapp.database.remote.model.PredictionInput
import retrofit2.Response

interface ApiHelperInterface {
    suspend fun ping(): Response<Any>
    suspend fun predict(predictionInput: PredictionInput): Response<Any>
}
