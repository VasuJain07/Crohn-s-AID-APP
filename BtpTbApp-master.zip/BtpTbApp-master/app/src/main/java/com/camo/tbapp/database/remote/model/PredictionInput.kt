package com.camo.tbapp.database.remote.model

import com.google.gson.annotations.SerializedName

// models in api include the data classes corresponding to gson response from the api
// u can use "gson to kotlin data class" plugin to generate this
data class PredictionInput(
    @SerializedName("ageAtFirstPresentation")
    val ageAtFirstPresentation: Int,
    @SerializedName("anyChestImaging")
    val anyChestImaging: Int,
    @SerializedName("apthousUlcers")
    val apthousUlcers: Int,
    @SerializedName("bleedingPrRectum")
    val bleedingPrRectum: Int,
    @SerializedName("Cobblestoning")
    val cobblestoning: Int,
    @SerializedName("combSign")
    val combSign: Int,
    @SerializedName("diarrheaMoreThan4Weeks")
    val diarrheaMoreThan4Weeks: Int,
    @SerializedName("Fever")
    val fever: Int,
    @SerializedName("Gender")
    val gender: Int,
    @SerializedName("granulomaOnBiopsy")
    val granulomaOnBiopsy: Int,
    @SerializedName("ileocecalValveInvolvement")
    val ileocecalValveInvolvement: Int,
    @SerializedName("longSegment")
    val longSegment: Int,
    @SerializedName("longitudinalUlcers")
    val longitudinalUlcers: Int,
    @SerializedName("muralStratisfaction")
    val muralStratisfaction: Int,
    @SerializedName("necroticLymphNodes")
    val necroticLymphNodes: Int,
    @SerializedName("pastHistoryOfTb")
    val pastHistoryOfTb: Int,
    @SerializedName("pseudopolyps")
    val pseudopolyps: Int,
    @SerializedName("pulmonaryDisease")
    val pulmonaryDisease: Int,
    @SerializedName("rectosigmoidInvolvement")
    val rectosigmoidInvolvement: Int,
    @SerializedName("rightAsWellAsLeftsidedColonicInvolvement")
    val rightAsWellAsLeftsidedColonicInvolvement: Int,
    @SerializedName("significantWeightLoss")
    val significantWeightLoss: Int,
    @SerializedName("skipLesions")
    val skipLesions: Int,
    @SerializedName("stricture")
    val stricture: Int,
    @SerializedName("transverseUlcers")
    val transverseUlcers: Int,
    @SerializedName("ugiInvolvement")
    val ugiInvolvement: Int
)
