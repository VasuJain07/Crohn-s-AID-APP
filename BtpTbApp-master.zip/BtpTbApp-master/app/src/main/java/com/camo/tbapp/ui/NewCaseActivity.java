package com.camo.tbapp.ui;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.text.format.DateFormat;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

import com.camo.tbapp.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.util.Date;

public class NewCaseActivity extends AppCompatActivity {

    EditText edt_uhid, edt_city, edt_pname, edt_pnum, edt_dname, edt_dnum;
    Button next;
    TextView t_date;

    private FirebaseAuth firebaseAuth;

    private FirebaseStorage firebaseStorage;
    private StorageReference storageReference;

    FirebaseDatabase firebaseDatabase;
    private DatabaseReference databaseReference;
    PatientInfo patientInfo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_case);

        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);

        Date date = new Date();
        CharSequence str = DateFormat.format("dd-MM-yyyy", date.getTime());

        edt_uhid = findViewById(R.id.edt_uhid);
        edt_city = findViewById(R.id.edt_city);
        edt_pname = findViewById(R.id.edt_pname);
        edt_pnum = findViewById(R.id.edt_pnum);
        edt_dname = findViewById(R.id.edt_dname);
        edt_dnum = findViewById(R.id.edt_dnum);
        next = findViewById(R.id.next);
        t_date = findViewById(R.id.t_date);

        t_date.setText(str);

        firebaseAuth = FirebaseAuth.getInstance();
        if (firebaseAuth.getCurrentUser() == null) {
            finish();
            startActivity(new Intent(getApplicationContext(), Profile.class));
        }
        databaseReference = FirebaseDatabase.getInstance().getReference();
        FirebaseUser user = firebaseAuth.getCurrentUser();
        firebaseStorage = FirebaseStorage.getInstance();
        storageReference = firebaseStorage.getReference();


        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String uhid = edt_uhid.getText().toString().trim();
                String city = edt_city.getText().toString().trim();
                String pname = edt_pname.getText().toString().trim();
                String pnum = edt_pnum.getText().toString().trim();
                String dname = edt_dname.getText().toString().trim();
                String dnum = edt_dnum.getText().toString().trim();

                if (TextUtils.isEmpty(uhid)) {
                    Toast.makeText(getApplicationContext(), "Please enter your uhid", Toast.LENGTH_LONG).show();
                    return;
                }

                if (TextUtils.isEmpty(city)) {
                    Toast.makeText(getApplicationContext(), "Please enter your City", Toast.LENGTH_LONG).show();
                    return;
                }

                if (TextUtils.isEmpty(pname)) {
                    Toast.makeText(getApplicationContext(), "Please enter your name", Toast.LENGTH_LONG).show();
                    return;
                }

                if (dnum.length() < 10) {
                    Toast.makeText(getApplicationContext(), "Please enter your number", Toast.LENGTH_LONG).show();
                    return;
                }

                if (TextUtils.isEmpty(dname)) {
                    Toast.makeText(getApplicationContext(), "Please enter your Physician name", Toast.LENGTH_LONG).show();
                    return;
                }

                if (dnum.length() < 10) {
                    Toast.makeText(getApplicationContext(), "Please enter your Physician number", Toast.LENGTH_LONG).show();
                    return;
                } else {
                    patientInformation();
                    finish();
                    startActivity(new Intent(NewCaseActivity.this, Profile.class));
                }

            }
        });
    }

    private void patientInformation() {
        String uhid = edt_uhid.getText().toString().trim();
        String city = edt_city.getText().toString().trim();
        String pname = edt_pname.getText().toString().trim();
        String pnum = edt_pnum.getText().toString().trim();
        String dname = edt_dname.getText().toString().trim();
        String dnum = edt_dnum.getText().toString().trim();
        String date = t_date.getText().toString().trim();

        PatientInfo patientInfo = new PatientInfo(uhid, city, pname, pnum, dname, dnum, date);
        FirebaseUser patient = firebaseAuth.getCurrentUser();
        databaseReference.child("PatientInfo").push().setValue(patientInfo);
    }
}