package com.camo.tbapp.database.remote.model

import com.google.gson.annotations.SerializedName

class PredictionOutput : ArrayList<PredictionOutput.PredictionOutputItem>() {
    data class PredictionOutputItem(
        @SerializedName("TB")
        val tB: Double,
        @SerializedName("UC")
        val uC: Double
    )
}
