package com.camo.tbapp.database.remote.api

import com.camo.tbapp.database.remote.model.PredictionInput
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST

interface ApiService {
    @GET("ping")
    suspend fun ping(): Response<Any>

    @POST("predict")
    suspend fun predict(@Body body: PredictionInput): Response<Any>
//    fun postJson(@Body body: FooRequest?): FooResponse?
}
