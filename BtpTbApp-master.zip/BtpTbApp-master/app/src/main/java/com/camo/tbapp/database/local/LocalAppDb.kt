package com.camo.tbapp.database.local
//
// import androidx.room.Database
// import androidx.room.RoomDatabase
// import com.camo.tbapp.database.local.dao.*
// import com.camo.tbapp.database.local.model.Coin
//
//
// // Increase version every time you make changes to room database structure
// @Database(entities = [Coin::class], version = 1)
// //@TypeConverters(DateTypeConverter::class)
// abstract class LocalAppDb : RoomDatabase() {
//    abstract fun coinDao(): CoinDao
// }
