package com.camo.tbapp.ui.viewmodels

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.camo.tbapp.R
import com.camo.tbapp.database.Repository
import com.camo.tbapp.ui.AddNewCaseActivity
import com.camo.tbapp.util.Constants
import com.camo.tbapp.util.Resource
import com.camo.tbapp.util.UiResource
import com.camo.tbapp.util.Utility
import com.camo.tbapp.util.Utility.ValidationLogic.validateClinicalInfo
import com.camo.tbapp.util.Utility.ValidationLogic.validateColonoscopyInfo
import com.camo.tbapp.util.Utility.ValidationLogic.validateImagingInfo
import com.camo.tbapp.util.Utility.ValidationLogic.validateMiscInfo
import com.camo.tbapp.util.Utility.ValidationLogic.validateOptionalInfo
import com.camo.tbapp.util.Utility.predict
import com.google.gson.JsonObject
import com.google.gson.JsonParser
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import timber.log.Timber
import java.text.SimpleDateFormat
import java.util.*
import javax.inject.Inject

@HiltViewModel
class AddNewCaseActivityVM @Inject constructor(
    private val repo: Repository,
    @ApplicationContext val context: Context
) : ViewModel() {

    private var _ugiInvolvement: Int? = null
    val ugiInvolvement: Int? get() = _ugiInvolvement

    private val _nextFab =
        MutableStateFlow<UiResource.StringResource?>(UiResource.StringResource(R.string.fill_data))
    val nextFab: StateFlow<UiResource.StringResource?> get() = _nextFab

    private val _prevFab = MutableStateFlow(false)
    val prevFab: StateFlow<Boolean> get() = _prevFab
    private val map = context.resources.getStringArray(R.array.term_name)
        .zip(context.resources.getStringArray(R.array.term_explanation)).toMap()

    //    Basic Info Fragment
    private var _basicInfoValid: UiResource.StringResource? =
        UiResource.StringResource(R.string.fill_data)
    private val _date: String
    val date: String get() = _date
    private var _uhid = ""
    val uhid: String get() = _uhid
    private var _city = ""
    val city: String get() = _city
    private var _patientName = ""
    val patientName: String get() = _patientName
    private var _physicianName = ""
    val physicianName: String get() = _physicianName
    private var _patientNumber = ""
    val patientNumber: String get() = _patientNumber
    private var _physicianNumber = ""
    val physicianNumber: String get() = _physicianNumber

    // FurtherInfoFragment
    private var _clinicalInfoValid: UiResource.StringResource? =
        UiResource.StringResource(R.string.fill_data)
    private var _imagingInfoValid: UiResource.StringResource? =
        UiResource.StringResource(R.string.fill_data)
    private var _colonoscopyInfoValid: UiResource.StringResource? =
        UiResource.StringResource(R.string.fill_data)
    private var _miscInfoValid: UiResource.StringResource? =
        UiResource.StringResource(R.string.fill_data)
    private val _furtherInfoValid: UiResource.StringResource?
        get() =
            when {
                _clinicalInfoValid != null -> _clinicalInfoValid
                _imagingInfoValid != null -> _imagingInfoValid
                _colonoscopyInfoValid != null -> _colonoscopyInfoValid
                _miscInfoValid != null -> _miscInfoValid
                else -> null
            }
    private val _expandedSection = MutableStateFlow(FurtherInfoSections.NONE)
    val expandedSection: StateFlow<FurtherInfoSections> get() = _expandedSection

    //    clinicalInfo
    private var _ageAtFPres = ""
    val ageAtPres: String get() = _ageAtFPres
    private var _gender: Int? = null
    val gender: Int? get() = _gender
    private var _symptomDurAtTFV = ("")
    val symptomDurAtTFV: String get() = _symptomDurAtTFV
    private var _pastHistTb: Int? = null
    val pastHistTb: Int? get() = _pastHistTb
    private var _bleedingPR: Int? = null
    val bleedingPR: Int? get() = _bleedingPR
    private var _perianalDis: Int? = null
    val perianalDis: Int? get() = _perianalDis
    private var _diarrhea: Int? = null
    val diarrhea: Int? get() = _diarrhea
    private var _pulmSymp: Int? = null
    val pulmSymp: Int? get() = _pulmSymp
    private var _fever: Int? = null
    val fever: Int? get() = _fever
    private var _sigWeightLoss: Int? = null
    val sigWeightLoss: Int? get() = _sigWeightLoss

    // imaging info
    private var _combSign: Int? = null
    val combSign: Int? get() = _combSign
    private var _muralStrat: Int? = null
    val muralStrat: Int? get() = _muralStrat
    private var _skipLesion: Int? = null
    val skipLesion: Int? get() = _skipLesion
    private var _longSeg: Int? = null
    val longSeg: Int? get() = _longSeg
    private var _necroticLymphNodes: Int? = null
    val necroticLymphNodes: Int? get() = _necroticLymphNodes
    private var _anyChestImaging: Int? = null
    val anyChestImaging: Int? get() = _anyChestImaging
    private var _stricture: Int? = null
    val stricture: Int? get() = _stricture
    private val _siteOfStricture = mutableSetOf<Int>()
    val siteOfStricure: Set<Int> get() = _siteOfStricture
    private var _ascities: Int? = null
    val ascites: Int? get() = _ascities
    private var _ada: Int? = null
    val ada: Int? get() = _ada

    // colonoscopy info
    private var _longUlcers: Int? = null
    val longUlcers: Int? get() = _longUlcers
    private var _unkTypeUlcers: Int? = null
    val unkTypeUlcers: Int? get() = _unkTypeUlcers
    private var _transUlcers: Int? = null
    val transUlcers: Int? get() = _transUlcers
    private var _apthUlcers: Int? = null
    val apthUlcers: Int? get() = _apthUlcers
    private var _cobblestoning: Int? = null
    val cobblestoning: Int? get() = _cobblestoning
    private var _rectoInvolvement: Int? = null
    val rectoInvolvement: Int? get() = _rectoInvolvement
    private var _iValveInvolv: Int? = null
    val iValveInvolv: Int? get() = _iValveInvolv
    private var _rlColonicInvolv: Int? = null
    val rlColonicInvolv: Int? get() = _rlColonicInvolv
    private var _pseudopolyps: Int? = null
    val pseudopolyps: Int? get() = _pseudopolyps

    // misc info
    private var _mantoux: Int? = null
    val mantoux: Int? get() = _mantoux
    private var _haemoglobin: String = ""
    val haemoglobin: String get() = _haemoglobin
    private var _albumin: String = ""
    val albumin: String get() = _albumin
    private var _globulin: String = ""
    val globulin: String get() = _globulin
    private var _granulomaOnBiopsy: Int? = null
    val granulomanOnBiopsy: Int? get() = _granulomaOnBiopsy

    // optional info
    private var _optionalInfoValid: UiResource.StringResource? = null
    val optionalInfoValid: UiResource.StringResource? get() = _optionalInfoValid
    private var _foxP3: String = ""
    val foxP3: String get() = _foxP3
    private var _igra: Int? = null
    val igra: Int? get() = _igra
    private var _visceralFat: String = ""
    val visceralFat: String get() = _visceralFat

    //    prediction
    private val _prediction =
        MutableStateFlow<Resource<JsonObject>>(Resource.idle())
    val prediction: StateFlow<Resource<JsonObject>> get() = _prediction
    private val _explainState = MutableStateFlow<String?>(null)
    val explainState: StateFlow<String?> get() = _explainState

    init {
        Timber.d("called")
        val c = Calendar.getInstance().time
        val df = SimpleDateFormat("dd-MMM-yyyy", Locale.getDefault())
        _date = df.format(c)
    }

    private var _currFrag = MutableStateFlow(AddNewCaseActivity.FragmentsMA.PREREQUISITE)
    val currFrag: StateFlow<AddNewCaseActivity.FragmentsMA> get() = _currFrag
    fun setCurrentFrag(frag: AddNewCaseActivity.FragmentsMA) {
        _currFrag.value = frag
        Timber.d("Current Frag - ${frag.title}")
        when (frag.pos) {
            0 -> {
                _prevFab.value = false
                _nextFab.value = null
            }
            1 -> {
                _prevFab.value = true
                _nextFab.value = null
            }
            2 -> {
                _prevFab.value = true
                _nextFab.value = UiResource.StringResource(R.string.fill_data)
                isBasicInfoValid()
            }
            3 -> {
                _prevFab.value = true
                _nextFab.value = UiResource.StringResource(R.string.fill_data)
                isFurtherInfoValid()
            }
            4 -> {
                _prevFab.value = true
                _nextFab.value = null
                isOptionalInfoValid()
            }
            5 -> {
                _prevFab.value = true
                _nextFab.value = null
            }
            else -> {
                Timber.e("Invalid MAFragment Position")
                throw java.lang.Exception("Invalid MAFragment Position")
            }
        }
    }

    private var validateFurtherInfoJob: Job? = null
    private fun isFurtherInfoValid() {
        validateFurtherInfoJob?.cancel()
        validateFurtherInfoJob = viewModelScope.launch {
            _clinicalInfoValid = validateClinicalInfo(
                symptomDurAtTFV,
                pastHistTb,
                bleedingPR,
                perianalDis,
                diarrhea,
                pulmSymp,
                fever,
                sigWeightLoss,
                ageAtPres,
                _gender
            )
            if (_clinicalInfoValid == null) {
                _imagingInfoValid = validateImagingInfo(
                    combSign,
                    muralStrat,
                    skipLesion,
                    longSeg,
                    necroticLymphNodes,
                    anyChestImaging,
                    stricture,
                    siteOfStricure,
                    ascites,
                    ada
                )
                if (_imagingInfoValid == null) {
                    _colonoscopyInfoValid = validateColonoscopyInfo(
                        longUlcers,
                        unkTypeUlcers,
                        transUlcers,
                        apthUlcers,
                        cobblestoning,
                        rectoInvolvement,
                        iValveInvolv,
                        rlColonicInvolv,
                        pseudopolyps
                    )
                    if (_colonoscopyInfoValid == null) {
                        _miscInfoValid = validateMiscInfo(
                            mantoux,
                            haemoglobin,
                            albumin,
                            globulin,
                            granulomanOnBiopsy,
                            ugiInvolvement
                        )
                    }
                }
            }
            _nextFab.value = _furtherInfoValid
            Timber.d("Fragment Data Validation:- \nFurtherInfo = ${_furtherInfoValid == null}, \nClinicalInfo = ${_clinicalInfoValid == null},\nColonoscopyInfo = ${_colonoscopyInfoValid == null},\nImagingInfo = ${_imagingInfoValid == null},\nMiscInfo = ${_miscInfoValid == null} ")
        }
    }

    private var validateBasicInfoJob: Job? = null
    private fun isBasicInfoValid() {
        validateBasicInfoJob?.cancel()
        validateBasicInfoJob = viewModelScope.launch {
            _basicInfoValid = Utility.ValidationLogic.validateBasicInfo(
                uhid,
                city,
                patientName,
                physicianName,
                patientNumber,
                physicianNumber
            )
            Timber.d("basicInfoValid = ${_basicInfoValid}")
            _nextFab.value = _basicInfoValid
        }
    }

    // parameters that require basicInfo revalidation on changing
    fun setUhid(uhid: String) {
        _uhid = uhid.trim()
        isBasicInfoValid()
    }

    fun setCity(city: String) {
        _city = city.trim()
        isBasicInfoValid()
    }

    fun setPatientNumber(number: String) {
        _patientNumber = number.trim()
        isBasicInfoValid()
    }

    fun setPatientName(name: String) {
        _patientName = name.trim()
        isBasicInfoValid()
    }

    fun setPhysicianName(name: String) {
        _physicianName = name.trim()
        isBasicInfoValid()
    }

    fun setPhysicianNumber(number: String) {
        _physicianNumber = number.trim()
        isBasicInfoValid()
    }

    fun setSection(section: FurtherInfoSections) {
        if (_expandedSection.value == section) _expandedSection.value =
            FurtherInfoSections.NONE else _expandedSection.value = section
    }

    fun explain(term: String?) {
        _explainState.value = term
    }

    fun getDesc(term: String): String {
        return map.getOrDefault(term, "NA")
    }

    // parameters that require furtherInfo revalidation on changing
    fun setGender(position: Int?) {
        _gender = position
        isFurtherInfoValid()
    }

    fun setAgeAtFPres(age: String) {
        _ageAtFPres = age.trim()
        isFurtherInfoValid()
    }

    fun setPastHistOfTb(position: Int?) {
        _pastHistTb = position
        isFurtherInfoValid()
    }

    fun setSigWeightLoss(position: Int?) {
        _sigWeightLoss = position
        isFurtherInfoValid()
    }

    fun setFever(position: Int?) {
        _fever = position
        isFurtherInfoValid()
    }

    fun setPulmSymptoms(position: Int?) {
        _pulmSymp = position
        isFurtherInfoValid()
    }

    fun setDiarrhea(position: Int?) {
        _diarrhea = position
        isFurtherInfoValid()
    }

    fun setPerianalDisease(position: Int?) {
        _perianalDis = position
        isFurtherInfoValid()
    }

    fun setBleedingPR(position: Int?) {
        _bleedingPR = position
        isFurtherInfoValid()
    }

    fun setPseudoPolyps(position: Int?) {
        _pseudopolyps = position
        isFurtherInfoValid()
    }

    fun setRLColonicI(position: Int?) {
        _rlColonicInvolv = position
        isFurtherInfoValid()
    }

    fun setIValveInvolvement(position: Int?) {
        _iValveInvolv = position
        isFurtherInfoValid()
    }

    fun setRectoInvolvement(position: Int?) {
        _rectoInvolvement = position
        isFurtherInfoValid()
    }

    fun setCobblestoning(position: Int?) {
        _cobblestoning = position
        isFurtherInfoValid()
    }

    fun setApthUlcers(position: Int?) {
        _apthUlcers = position
        isFurtherInfoValid()
    }

    fun setTransverseUlc(position: Int?) {
        _transUlcers = position
        isFurtherInfoValid()
    }

    fun setLongUlcers(position: Int?) {
        _longUlcers = position
        isFurtherInfoValid()
    }

    fun setUnkTypeUlcers(position: Int?) {
        _unkTypeUlcers = position
        isFurtherInfoValid()
    }

    fun setAda(position: Int?) {
        _ada = position
        isFurtherInfoValid()
    }

    fun setAnyChestImaging(position: Int?) {
        _anyChestImaging = position
        isFurtherInfoValid()
    }

    fun setAscites(position: Int?) {
        _ascities = position
        isFurtherInfoValid()
    }

    fun setCombSign(position: Int?) {
        _combSign = position
        isFurtherInfoValid()
    }

    fun setLongSeg(position: Int?) {
        _longSeg = position
        isFurtherInfoValid()
    }

    fun setMuralSTSign(position: Int?) {
        _muralStrat = position
        isFurtherInfoValid()
    }

    fun setNecroticLymphNodes(position: Int?) {
        _necroticLymphNodes = position
        isFurtherInfoValid()
    }

    fun setSkipLesion(position: Int?) {
        _skipLesion = position
        isFurtherInfoValid()
    }

    fun setStricture(position: Int?) {
        _stricture = position
        isFurtherInfoValid()
    }

    fun setGranulomaOnBiopsy(position: Int?) {
        _granulomaOnBiopsy = position
        isFurtherInfoValid()
    }

    fun setMantoux(position: Int?) {
        _mantoux = position
        isFurtherInfoValid()
    }

    fun addSiteOfStricture(stricture: Constants.SiteOfStricture, b: Boolean) {
        if (b) {
            _siteOfStricture.add(stricture.key)
        } else {
            _siteOfStricture.remove(stricture.key)
        }
        isFurtherInfoValid()
    }

    fun setAlbumin(albumin: String) {
        _albumin = albumin.trim()
        isFurtherInfoValid()
    }

    fun setHaemoglobin(haemoglobin: String) {
        _haemoglobin = haemoglobin.trim()
        isFurtherInfoValid()
    }

    fun setGlobulin(globulin: String) {
        _globulin = globulin.trim()
        isFurtherInfoValid()
    }

    fun setDurationAtTimeFV(dur: String) {
        _symptomDurAtTFV = dur
        isFurtherInfoValid()
    }

    private var validateOptionalInfoValidJob: Job? = null
    private fun isOptionalInfoValid() {
        validateOptionalInfoValidJob?.cancel()
        validateOptionalInfoValidJob = viewModelScope.launch {
            _optionalInfoValid = validateOptionalInfo(foxP3, igra, visceralFat)
            _nextFab.value = _optionalInfoValid
        }
    }

    // parameters that require optionalInfo revalidation on changing
    fun setFox(foxp3: String) {
        _foxP3 = foxp3
        isOptionalInfoValid()
    }

    fun setVisceralFat(vFat: String) {
        _visceralFat = vFat
        isOptionalInfoValid()
    }

    fun setIgra(position: Int?) {
        _igra = position
        isOptionalInfoValid()
    }

    private var submitJob: Job? = null
    fun submit() {
        submitJob?.cancel()
        submitJob = GlobalScope.launch {
            _prediction.value = Resource.loading()
            val x = predict(
                ageAtPres.toInt(),
                getValueFromArray(R.array.value_gender, gender!!),
                getValueFromArray(R.array.value_past_hist_tb, pastHistTb!!),
                symptomDurAtTFV.toInt(),
                haemoglobin.toDouble(),
                getValueFromArray(R.array.value_yes_no, bleedingPR!!),
                getValueFromArray(R.array.value_yes_no, perianalDis!!),
                getValueFromArray(R.array.value_yes_no, diarrhea!!),
                getValueFromArray(R.array.value_yes_no, pulmSymp!!),
                getValueFromArray(R.array.value_yes_no, fever!!),
                getValueFromArray(R.array.value_yes_no, fever!!),
                getValueFromArray(R.array.value_yes_no, combSign!!),
                getValueFromArray(R.array.value_yes_no, muralStrat!!),
                getValueFromArray(R.array.value_yes_no, skipLesion!!),
                getValueFromArray(R.array.value_yes_no, longSeg!!),
                getValueFromArray(R.array.value_yes_no, necroticLymphNodes!!),
                getValueFromArray(R.array.value_chest_imaging, anyChestImaging!!),
                getValueFromArray(R.array.value_yes_no, stricture!!),
                getValueFromArray(R.array.value_yes_no, longUlcers!!),
                getValueFromArray(R.array.value_yes_no, transUlcers!!),
                getValueFromArray(R.array.value_yes_no, apthUlcers!!),
                getValueFromArray(R.array.value_yes_no, cobblestoning!!),
                getValueFromArray(R.array.value_yes_no, rectoInvolvement!!),
                getValueFromArray(R.array.value_yes_no, iValveInvolv!!),
                getValueFromArray(R.array.value_yes_no, rlColonicInvolv!!),
                getValueFromArray(R.array.value_yes_no, pseudopolyps!!),
                getValueFromArray(R.array.value_granuloma_biopsy, granulomanOnBiopsy!!),
                getValueFromArray(R.array.value_yes_no, ugiInvolvement!!)
            )
            val y = x.substring(1, x.length - 1)
            try {
                _prediction.value = Resource.success(JsonParser().parse(y).asJsonObject)
            } catch (e: Exception) {
                _prediction.value = Resource.error(null, "error")
                Timber.d("Error")
                e.printStackTrace()
            }
            Timber.d("Predicted value = ${_prediction.value}")
        }
    }

    private fun getValueFromArray(resourceId: Int, pos: Int): Int {
        return context.resources.getIntArray(resourceId)[pos]
    }

    fun setUgiInvolvement(position: Int) {
        _ugiInvolvement = position
        isFurtherInfoValid()
    }

    companion object {
        enum class FurtherInfoSections {
            CLINICAL_INFO,
            IMAGING,
            COLONOSCOPY,
            MISC,
            NONE
        }
    }
}
