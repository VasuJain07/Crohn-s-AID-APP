package com.camo.tbapp.database

import com.camo.tbapp.database.remote.api.PredictionApiHelper
import com.camo.tbapp.database.remote.model.PredictionInput
import com.camo.tbapp.database.remote.model.PredictionOutput
import com.camo.tbapp.util.Resource
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import retrofit2.Response
import timber.log.Timber
import javax.inject.Inject

class Repository @Inject constructor(val predictionApiHelper: PredictionApiHelper) {
    suspend fun pingCG(): Flow<Resource<Response<Any>>> {
        return flow {
            emit(Resource.loading(data = null))
            try {
                val res = predictionApiHelper.ping()
                Timber.d(res.toString())
                if (res.isSuccessful && res.code() == 200) emit(Resource.success(res))
                else {
                    Timber.d(res.toString())
                    emit(Resource.error(res, "Couldn't ping server"))
                }
            } catch (e: Exception) {
                Timber.d(e)
                emit(Resource.error(null, "Couldn't ping server"))
            }
        }
    }

    suspend fun predict(predictionInput: PredictionInput): Flow<Resource<PredictionOutput>> {
        return flow {
            emit(Resource.loading())
            try {
                val res = predictionApiHelper.predict(predictionInput)
                Timber.d("$res, ${res.body()}")
                if (res.isSuccessful && res.code() == 200) emit(Resource.success(res.body() as PredictionOutput))
            } catch (e: Exception) {
                e.printStackTrace()
                Timber.e(e.localizedMessage)
                emit(Resource.error(null, "Something went wrong"))
            }
        }
    }
}
