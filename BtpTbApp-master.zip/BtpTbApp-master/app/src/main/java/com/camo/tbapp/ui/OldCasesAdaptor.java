package com.camo.tbapp.ui;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.camo.tbapp.R;

import java.util.ArrayList;

public class OldCasesAdaptor extends RecyclerView.Adapter<OldCasesAdaptor.ViewHolder> {
    // creating variables for our ArrayList and context
    private ArrayList<PatientInfo> patientInfoArrayList;
    private Context context;

    // creating constructor for our adapter class
    public OldCasesAdaptor(ArrayList<PatientInfo> patientInfoArrayList, Context context) {
        this.patientInfoArrayList = patientInfoArrayList;
        this.context = context;
    }

    @NonNull
    @Override
    public OldCasesAdaptor.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // passing our layout file for displaying our card item
        return new ViewHolder(LayoutInflater.from(context).inflate(R.layout.patientlist, parent, false));
    }

    @SuppressLint("SetTextI18n")
    @Override
    public void onBindViewHolder(@NonNull OldCasesAdaptor.ViewHolder holder, int position) {
        // setting data to our text views from our modal class.
        PatientInfo patientInfo = patientInfoArrayList.get(position);
        holder.uhid.setText(patientInfo.getUhid());
        holder.pname.setText(patientInfo.getPname());
        holder.pnum.setText(patientInfo.getPnum());
        holder.city.setText(patientInfo.getCity());
        holder.dname.setText(patientInfo.getDname());
        holder.dnum.setText(patientInfo.getDnum());
        holder.date.setText(patientInfo.getDate());
    }

    @Override
    public int getItemCount() {
        // returning the size of our array list.
        return patientInfoArrayList.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder {
        // creating variables for our text views.
        private final TextView uhid;
        private final TextView pname;
        private final TextView pnum;
        private final TextView dname;
        private final TextView dnum;
        private final TextView city;
        private final TextView date;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            // initializing our text views.
            uhid = itemView.findViewById(R.id.uhid);
            pname = itemView.findViewById(R.id.Pname);
            pnum = itemView.findViewById(R.id.Pnum);
            city = itemView.findViewById(R.id.city);
            dname = itemView.findViewById(R.id.Dname);
            dnum = itemView.findViewById(R.id.Dnum);
            date = itemView.findViewById(R.id.date);
        }
    }
}

