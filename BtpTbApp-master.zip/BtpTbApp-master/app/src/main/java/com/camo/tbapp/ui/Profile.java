package com.camo.tbapp.ui;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

import com.camo.tbapp.R;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class Profile extends AppCompatActivity {

    Button newcase_btn, oldcase_btn;
    FloatingActionButton fabPrev, fabNext;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        newcase_btn = findViewById(R.id.newcase_btn);
        oldcase_btn = findViewById(R.id.oldcase_btn);
        fabPrev = findViewById(R.id.fabPrev);
        fabNext = findViewById(R.id.fabNext);

        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);

        newcase_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // go the main app
                Intent intent = new Intent(Profile.this, AddNewCaseActivity.class);
                startActivity(intent);
            }
        });

        oldcase_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Profile.this, OldCaseActivity.class);
                startActivity(intent);
            }
        });

/*        fabPrev.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // go the main app
                Intent intent = new Intent(Profile.this, MainActivity.class);
                startActivity(intent);
            }
        });

        fabNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Profile.this, MainActivity.class);
                startActivity(intent);
            }
        });
        
 */

    }
}