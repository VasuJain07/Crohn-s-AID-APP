package com.camo.tbapp.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.lifecycleScope
import com.camo.tbapp.R
import com.camo.tbapp.databinding.FragmentPredictionBinding
import com.camo.tbapp.ui.viewmodels.AddNewCaseActivityVM
import com.camo.tbapp.util.Status
import kotlinx.coroutines.flow.collect
import timber.log.Timber
import kotlin.math.roundToInt

class PredictionFragment : Fragment() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Timber.d("onCreate called")
    }

    private var _binding: FragmentPredictionBinding? = null

    // valid from onCreateView to onDestroy
    private val binding: FragmentPredictionBinding get() = _binding!!
    private val viewModel by activityViewModels<AddNewCaseActivityVM>()
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        _binding = FragmentPredictionBinding.inflate(inflater, container, false)
        setupListeners()
        return binding.root
    }

    private fun setupListeners() {
        lifecycleScope.launchWhenStarted {
            viewModel.prediction.collect {
                when (it.status) {
                    Status.IDLE -> {
                        binding.srl.isRefreshing = false
                        binding.tvPred1.text = "-"
                        binding.tvPred2.text = "-"
                    }
                    Status.SUCCESS -> {
                        binding.srl.isRefreshing = false
                        var prob = ((it.data?.get("TB").toString().toDoubleOrNull())) ?: 0.0
                        prob = (prob * 100.0).roundToInt() / 100.0
                        prob *= 100
                        binding.tvPred1.text = prob.roundToInt().toString()+" %"
                        if (prob < 50) {
                            binding.tvPred2.text = requireContext().getString(R.string.yes)
                        } else {
                            binding.tvPred2.text = requireContext().getString(R.string.no)
                        }
                        when (prob) {
                            in 1.0..17.0 -> { binding.ivPred1.setImageResource(R.drawable.meter1) }
                            in 17.0..32.0 -> { binding.ivPred1.setImageResource(R.drawable.meter2) }
                            in 32.0..48.0 -> { binding.ivPred1.setImageResource(R.drawable.meter3) }
                            in 48.0..60.0 -> { binding.ivPred1.setImageResource(R.drawable.meter4) }
                            in 60.0..76.0 -> { binding.ivPred1.setImageResource(R.drawable.meter5) }
                            else -> { binding.ivPred1.setImageResource(R.drawable.meter6) }
                        }
                    }
                    Status.LOADING -> {
                        binding.srl.isRefreshing = true
                        binding.tvPred2.text = "-"
                        binding.tvPred1.text = "-"
                    }
                    Status.ERROR -> {
                        binding.srl.isRefreshing = false
                        binding.tvPred1.text = "E"
                        binding.tvPred2.text = "E"
                    }
                }
            }
        }
        binding.srl.setOnRefreshListener {
            viewModel.submit()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        _binding = null
    }
}
