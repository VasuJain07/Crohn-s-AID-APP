package com.camo.tbapp.ui

import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.view.LayoutInflater
import androidx.appcompat.app.AppCompatActivity
import com.camo.tbapp.databinding.ActivityDisclaimerBinding
import com.camo.tbapp.util.ContextUtility
import com.camo.tbapp.util.ContextUtility.checkAppStart
import dagger.hilt.android.AndroidEntryPoint
import timber.log.Timber
import javax.inject.Inject

@AndroidEntryPoint
class DisclaimerActivity : AppCompatActivity() {
    private lateinit var binding: ActivityDisclaimerBinding

    @Inject
    lateinit var sharedPreferences: SharedPreferences
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDisclaimerBinding.inflate(
            LayoutInflater.from(this)
        )
        setContentView(binding.root)
        supportActionBar?.title = "Disclaimer"
        Timber.i("Disclaimer Activity launched")
        if (checkAppStart(this, sharedPreferences) == ContextUtility.AppStart.NORMAL) {
            proceed()
        }
        with(binding) {
            btnAccept.setOnClickListener {
                proceed()
            }
            btnDeny.setOnClickListener {
                finish()
            }
        }
    }


    private fun proceed() {
        val intent = Intent(this, LoginActivity::class.java)
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
        startActivity(intent)
        finish()
    }
}
