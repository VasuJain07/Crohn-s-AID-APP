package com.camo.tbapp.ui;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

import com.camo.tbapp.R;

public class OTPLoginActivity extends AppCompatActivity {

    EditText editTextPhone;
    Button buttonContinue;
    TextView signInBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_otplogin);
        signInBtn = findViewById(R.id.idBtnGetOtp);

        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);

        signInBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String number = editTextPhone.getText().toString().trim();
                if (number.isEmpty() || number.length() < 10) {
                    editTextPhone.setError("Valid number is required");
                    editTextPhone.requestFocus();
                    return;
                }
                String phoneNumber = "+91" + number;

                Intent intent = new Intent(OTPLoginActivity.this, OTPVerificationActivity.class);
                intent.putExtra("phoneNumber", phoneNumber);
                startActivity(intent);

            }
        });
    }


    public void OnClick(View view) {
        Intent intent = new Intent(OTPLoginActivity.this, SignupActivity.class);
        startActivity(intent);
    }
}