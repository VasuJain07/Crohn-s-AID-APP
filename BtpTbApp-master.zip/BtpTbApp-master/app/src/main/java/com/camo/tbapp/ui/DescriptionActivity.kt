package com.camo.tbapp.ui

import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.LayoutInflater
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.camo.tbapp.databinding.ActivityDescriptionBinding
import com.camo.tbapp.util.Utility.PERMISSIONS_ALL
import com.camo.tbapp.util.Utility.PreferenceKey.DEBUG
import com.camo.tbapp.util.Utility.PreferenceKey.LAUNCH_COUNT
import com.camo.tbapp.util.Utility.REQUIRED_PERMISSIONS
import dagger.hilt.android.AndroidEntryPoint
import timber.log.Timber
import javax.inject.Inject

@AndroidEntryPoint
class DescriptionActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDescriptionBinding

    @Inject
    lateinit var sharedPreferences: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDescriptionBinding.inflate(
            LayoutInflater.from(this)
        )
        setContentView(binding.root)
        Timber.i("Description Activity launched")

        setDefaultPreferences()
        binding.btnAccept.isEnabled = false
        askPerms()
        binding.btnAccept.setOnClickListener {
            val intent = Intent(this, DisclaimerActivity::class.java)
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
            startActivity(intent)
            finish()
        }
    }

    private fun setDefaultPreferences() {
        val editor = sharedPreferences.edit()
        if (!sharedPreferences.contains(DEBUG)) {
            editor.putBoolean(DEBUG, false)
        }
        editor.putInt(LAUNCH_COUNT, sharedPreferences.getInt(LAUNCH_COUNT, 0) + 1)
        editor.apply()
    }

    private fun askPerms() {
        if (allPermissionsGranted()) {
            enableProceedButton()
        } else {
            ActivityCompat.requestPermissions(
                this, REQUIRED_PERMISSIONS, PERMISSIONS_ALL
            )
        }
    }

    private fun enableProceedButton() {
        binding.btnAccept.isEnabled = true
    }

    private fun allPermissionsGranted() = REQUIRED_PERMISSIONS.all {
        ContextCompat.checkSelfPermission(
            baseContext, it
        ) == PackageManager.PERMISSION_GRANTED
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<String>,
        grantResults:
            IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == PERMISSIONS_ALL) {
            for (i in permissions.indices) {
                Timber.d("$i")
                val permission = permissions[i]
                if (grantResults[i] == PackageManager.PERMISSION_DENIED) {
                    // user rejected the permission
                    val showRationale = shouldShowRequestPermissionRationale(permission)
                    if (!showRationale) {
                        // user also CHECKED "never ask again"
                        // you can either enable some fall back,
                        // disable features of your app
                        // or open another dialog explaining
                        // again the permission and directing to
                        // the app setting
                        Toast.makeText(this, "Permissions Not Granted", Toast.LENGTH_LONG).show()
                        val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                        val uri: Uri = Uri.fromParts("package", packageName, null)
                        intent.data = uri
                        startActivity(intent)
//                        finish()
                    }
                }
            }
            if (allPermissionsGranted()) {
                askPerms()
            }
        }
    }
}
