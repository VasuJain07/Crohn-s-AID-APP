package com.camo.tbapp.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.viewpager2.widget.ViewPager2
import com.camo.tbapp.databinding.ActivityAddNewCaseBinding
import com.camo.tbapp.ui.adapters.ViewPagerFragmentAdapter
import com.camo.tbapp.ui.viewmodels.AddNewCaseActivityVM
import com.camo.tbapp.util.Utility.ViewAnimationUtils.collapse
import com.camo.tbapp.util.Utility.ViewAnimationUtils.expand
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.flow.collect
import timber.log.Timber
import java.lang.Integer.max
import java.lang.Integer.min

@AndroidEntryPoint
class AddNewCaseActivity : AppCompatActivity() {
    private lateinit var binding: ActivityAddNewCaseBinding
    private val viewModel: AddNewCaseActivityVM by viewModels()

    private lateinit var fragmentAdapter: ViewPagerFragmentAdapter
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAddNewCaseBinding.inflate(
            LayoutInflater.from(this)
        )
        setContentView(binding.root)
        Timber.i("AddNewCaseActivity launched")
        setUpUI()
        setUpListeners()
    }

    private fun setUpListeners() {
        val pageChangeListener = object : ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) {
                if (position == 0) binding.fabPrev.visibility = View.GONE
                else binding.fabPrev.visibility = View.VISIBLE
                if (position == 5) binding.fabNext.visibility = View.GONE
                else binding.fabNext.visibility = View.VISIBLE

                viewModel.setCurrentFrag(
                    when (position) {
                        1 -> {
                            FragmentsMA.VARIABLES
                        }
                        2 -> {
                            FragmentsMA.BASIC_INFO
                        }
                        3 -> FragmentsMA.FURTHER_INFO
                        4 -> FragmentsMA.OPTIONAL_INFO
                        5 -> {
                            FragmentsMA.PREDICTION
                        }
                        else -> {
                            FragmentsMA.PREREQUISITE
                        }
                    }
                )
            }
        }
        binding.viewPager.registerOnPageChangeCallback(pageChangeListener)
        binding.fabNext.setOnClickListener {
            when (viewModel.currFrag.value) {
                FragmentsMA.OPTIONAL_INFO -> {
                    submit()
                }
                FragmentsMA.PREREQUISITE, FragmentsMA.VARIABLES -> {
                    binding.viewPager.setCurrentItem(
                        min(
                            binding.viewPager.currentItem + 1,
                            fragmentAdapter.getLength()
                        ),
                        true
                    )
                }
                else -> {
                    viewModel.nextFab.value?.let {
                        Toast.makeText(
                            this@AddNewCaseActivity,
                            it.asString(this), Toast.LENGTH_LONG
                        ).show()
                    } ?: binding.viewPager.setCurrentItem(
                        min(
                            binding.viewPager.currentItem + 1,
                            fragmentAdapter.getLength()
                        ),
                        true
                    )
                }
            }
        }
        binding.fabPrev.setOnClickListener {
            binding.viewPager.setCurrentItem(max(binding.viewPager.currentItem - 1, 0), true)
        }
        binding.tvDesc.button.setOnClickListener {
            viewModel.explain(null)
        }
        lifecycleScope.launchWhenStarted {
            viewModel.currFrag.collect {
                binding.tvTitle.text = it.title
            }
        }

        lifecycleScope.launchWhenStarted {
            viewModel.prevFab.collect {
                binding.fabPrev.isEnabled = it
            }
        }
        lifecycleScope.launchWhenStarted {
            viewModel.explainState.collect {
                if (it == null) {
                    collapse(binding.tvDesc.root)
                } else {
                    binding.tvDesc.tvKey.text = it
                    binding.tvDesc.tvExplanation.text = viewModel.getDesc(it)
                    expand(binding.tvDesc.root)
                }
            }
        }
    }

    private fun submit() {
//        Toast.makeText(this, predict(1,), Toast.LENGTH_SHORT).show()
        binding.viewPager.setCurrentItem(
            min(
                binding.viewPager.currentItem + 1,
                fragmentAdapter.getLength()
            ),
            true
        )
        viewModel.submit()
    }

    private fun setUpUI() {
        fragmentAdapter = ViewPagerFragmentAdapter(supportFragmentManager, lifecycle)
        fragmentAdapter.addFragment(
            Fragment1Prerequisite(),
            Fragment1p1Variables(),
            Fragment2BasicInfo(),
            Fragment3FurtherInfo(),
            Fragment4OptionalInfo(),
            PredictionFragment()
        )
        binding.viewPager.adapter = fragmentAdapter
        binding.viewPager.isUserInputEnabled = false
    }

    enum class FragmentsMA(val pos: Int, val title: String) {
        PREREQUISITE(0, "Prerequisite"),
        VARIABLES(1, "Requirements"),
        BASIC_INFO(2, "Basic Info"),
        FURTHER_INFO(3, "Clinical Details"),
        OPTIONAL_INFO(4, "Additional Info"),
        PREDICTION(5, "Outcome")
    }
}
