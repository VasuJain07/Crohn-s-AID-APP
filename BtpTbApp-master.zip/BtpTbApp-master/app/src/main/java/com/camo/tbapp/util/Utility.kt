package com.camo.tbapp.util

import android.Manifest
import android.view.View
import android.view.ViewGroup
import android.view.animation.Animation
import android.view.animation.Transformation
import com.camo.tbapp.R
import timber.log.Timber
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import java.util.*
import java.util.zip.GZIPInputStream


object Utility {
    object PreferenceKey {
        const val DEBUG = "debug"
        const val LAUNCH_COUNT = "launch_count"
    }

    const val PERMISSIONS_ALL = 1
    val REQUIRED_PERMISSIONS = arrayOf(
        Manifest.permission.WRITE_EXTERNAL_STORAGE,
        Manifest.permission.READ_EXTERNAL_STORAGE,
        Manifest.permission.ACCESS_NETWORK_STATE,
        Manifest.permission.INTERNET
    )

    object ValidationLogic {
        fun validateBasicInfo(
            uhid: String,
            city: String,
            patientName: String,
            physicianName: String,
            patientNumber: String,
            physicianNumber: String
        ): UiResource.StringResource? {
            // mandatory fields
            // patientName, physicianName, patientAge, gender
//            TODO validate uhid if needed
            if (patientName.isBlank()) return UiResource.StringResource(R.string.patient_name_reqd)
            if (physicianName.isBlank()) return UiResource.StringResource(R.string.physician_name_reqd)
            if (!isNameValid(patientName)) return UiResource.StringResource(R.string.invalid_patient_name)
            if (!isNameValid(physicianName)) return UiResource.StringResource(R.string.invalid_physician_name)

            if (city.isNotBlank() && !isNameValid(city)) return UiResource.StringResource(R.string.city_invalid)
            if (patientNumber.isNotBlank() && !isPhoneNumberValid(patientNumber)) return UiResource.StringResource(
                R.string.invalid_patient_number
            )
            if (physicianNumber.isNotBlank() && !isPhoneNumberValid(physicianNumber)) return UiResource.StringResource(
                R.string.invalid_physician_number
            )
            return null
        }

        fun validateMiscInfo(
            mantoux: Int?,
            haemoglobin: String,
            albumin: String,
            globulin: String,
            granulomaOnBiopsy: Int?,
            ugiInvolv: Int?
        ): UiResource.StringResource? {
            Timber.d("MiscInfo = $mantoux,$haemoglobin,$albumin,$globulin,$granulomaOnBiopsy,")
            if (mantoux == null || granulomaOnBiopsy == null) return UiResource.StringResource(R.string.invalid)
            if (mantoux < 0 || mantoux > 1) return UiResource.StringResource(R.string.invalid)
            if (granulomaOnBiopsy < 0 || granulomaOnBiopsy > 5) return UiResource.StringResource(R.string.invalid)
            if (!isHaemoglobinValid(haemoglobin)) return UiResource.StringResource(R.string.invalid)
            if (!isAlbuminValid(albumin)) return UiResource.StringResource(R.string.invalid)
            if (!isGlobulinValid(globulin)) return UiResource.StringResource(R.string.invalid)
            if(ugiInvolv == null || ugiInvolv<0 || ugiInvolv>2) return UiResource.StringResource(R.string.invalid)
            return null
        }

        fun validateColonoscopyInfo(
            longUlcers: Int?,
            unkTypeUlcers: Int?,
            transUlcers: Int?,
            apthUlcers: Int?,
            cobblestoning: Int?,
            rectoInvolvement: Int?,
            iValveInvolv: Int?,
            rlColonicInvolv: Int?,
            pseudopolyps: Int?
        ): UiResource.StringResource? {
            Timber.d("$longUlcers,$unkTypeUlcers,$transUlcers,$apthUlcers,$cobblestoning,$rectoInvolvement,$iValveInvolv,$rlColonicInvolv,$pseudopolyps,")
            if (longUlcers == null ||
                unkTypeUlcers == null ||
                transUlcers == null ||
                apthUlcers == null ||
                cobblestoning == null ||
                rectoInvolvement == null ||
                iValveInvolv == null ||
                rlColonicInvolv == null ||
                pseudopolyps == null
            ) return UiResource.StringResource(R.string.invalid)
            if (longUlcers < 0 ||
                unkTypeUlcers < 0 ||
                transUlcers < 0 ||
                apthUlcers < 0 ||
                cobblestoning < 0 ||
                rectoInvolvement < 0 ||
                iValveInvolv < 0 ||
                rlColonicInvolv < 0 ||
                pseudopolyps < 0
            ) return UiResource.StringResource(R.string.invalid)
            if (longUlcers > 1 ||
                unkTypeUlcers > 1 ||
                transUlcers > 1 ||
                apthUlcers > 1 ||
                cobblestoning > 1 ||
                rectoInvolvement > 1 ||
                iValveInvolv > 1 ||
                rlColonicInvolv > 1 ||
                pseudopolyps > 1
            ) return UiResource.StringResource(R.string.invalid)
            return null
        }

        fun validateClinicalInfo(
            symDurAFT: String,
            pastHistTb: Int?,
            bleedingPR: Int?,
            perianalDis: Int?,
            diarrhea: Int?,
            pulmSymptoms: Int?,
            fever: Int?,
            sigWeightLoss: Int?,
            ageAtFirstPresentationInYears: String,
            gender: Int?
        ): UiResource.StringResource? {
            Timber.d("$symDurAFT, $pastHistTb, $bleedingPR, $perianalDis, $diarrhea, $pulmSymptoms, $fever, $sigWeightLoss, $ageAtFirstPresentationInYears, $gender")
            if (gender == null) return UiResource.StringResource(R.string.gender_is_reqd)
            if (gender > 2 || gender < 0) return UiResource.StringResource(R.string.invalid_gender)
            if (ageAtFirstPresentationInYears.isBlank()) return UiResource.StringResource(R.string.afp_reqd)
            if (!isAgeValid(ageAtFirstPresentationInYears)) return UiResource.StringResource(R.string.invalid_afp)
            val x = symDurAFT.toIntOrNull()
            if (x == null || pastHistTb == null || bleedingPR == null || perianalDis == null || diarrhea == null || diarrhea < 0 || pulmSymptoms == null || fever == null || sigWeightLoss == null) return UiResource.StringResource(
                R.string.invalid
            )
            if (x < 0 || x > 1800 || pastHistTb < 0 || bleedingPR < 0 || perianalDis < 0 || diarrhea < 0 || pulmSymptoms < 0 || fever < 0 || sigWeightLoss < 0) return UiResource.StringResource(
                R.string.invalid
            )
            if (pastHistTb > 2 || bleedingPR > 1 || perianalDis > 1 || diarrhea > 1 || pulmSymptoms > 1 || fever > 1 || sigWeightLoss > 1) return UiResource.StringResource(
                R.string.invalid
            )

            return null
        }

        fun validateImagingInfo(
            combSign: Int?,
            muralStrat: Int?,
            skipLesion: Int?,
            longSeg: Int?,
            necroticLymphNodes: Int?,
            anyChestImaging: Int?,
            stricture: Int?,
            siteOfStricture: Set<Int>,
            ascites: Int?,
            ada: Int?
        ): UiResource.StringResource? {
            Timber.d("$combSign,$muralStrat,$skipLesion,$longSeg,$necroticLymphNodes,$anyChestImaging,$stricture,$siteOfStricture,$ascites,$ada")
            if (combSign == null ||
                muralStrat == null ||
                skipLesion == null ||
                longSeg == null ||
                necroticLymphNodes == null ||
                anyChestImaging == null ||
                stricture == null ||
                ascites == null ||
                ada == null
            ) return UiResource.StringResource(R.string.invalid)
            if (siteOfStricture.size > 4) return UiResource.StringResource(R.string.invalid)
            for (x in siteOfStricture) {
                if (x < 1 || x > 5) return UiResource.StringResource(R.string.invalid)
            }
            if (combSign < 0 ||
                muralStrat < 0 ||
                skipLesion < 0 ||
                longSeg < 0 ||
                necroticLymphNodes < 0 ||
                anyChestImaging < 0 ||
                stricture < 0 ||
                ascites < 0 ||
                ada < 0
            ) return UiResource.StringResource(R.string.invalid)
            if (combSign > 1 ||
                muralStrat > 1 ||
                skipLesion > 1 ||
                longSeg > 1 ||
                necroticLymphNodes > 2 ||
                anyChestImaging > 5 ||
                stricture > 1 ||
                ascites > 1 ||
                ada > 2
            ) return UiResource.StringResource(R.string.invalid)
            return null
        }

        fun isNameValid(name: String): Boolean {
            if (name.isBlank()) return false
            val names = name.split(' ')
            var ans = true
            for (x in names) {
                ans = x.matches(Regex("^[a-zA-Z]+(([',. -][a-zA-Z ])?[a-zA-Z]*)*\$"))
                if (!ans) return ans
            }
            return ans
        }

        private fun isPhoneNumberValid(num: String): Boolean {
            var ans = true
            if (num.length != 10) {
                return false
            }
            for (i in 0..9) {
                val a = num[i]
                ans = ans && a >= '0' && a <= '9'
            }
            return ans
        }

        private fun isAgeValid(age: String): Boolean {
            return try {
                val x = age.toInt()
                x in 0..150
            } catch (e: NumberFormatException) {
                false
            }
        }

        fun isHaemoglobinValid(haemoglobin: String): Boolean {
            if (haemoglobin.isBlank()) return false
            val h = haemoglobin.toDoubleOrNull()
            if (h == null || h < 0 || h > 40) return false
            return true
        }

        private fun isAlbuminValid(albumin: String): Boolean {
            try {
                val f: Float = albumin.toFloat()
//                TODO apply checks
                // return (f>=0 && f<=20);
            } catch (nfe: NumberFormatException) {
                return false
            }
            return true
        }

        private fun isGlobulinValid(globulin: String): Boolean {
            try {
                val f: Float = globulin.toFloat()
//                TODO apply checks
                // return (f>=0 && f<=20);
            } catch (nfe: NumberFormatException) {
                return false
            }
            return true
        }

        private fun isFoxP3Valid(foxp3: String): Boolean {
            return try {
                val f: Float = foxp3.toFloat()
                f in 0.0..100.0
            } catch (nfe: NumberFormatException) {
                false
            }
        }

        private fun isVisceralFatValid(vf: String): Boolean {
            return try {
                vf.toFloat()
                true
            } catch (nfe: NumberFormatException) {
                false
            }
        }

        fun validateOptionalInfo(
            foxP3: String,
            igra: Int?,
            visceralFat: String
        ): UiResource.StringResource? {
            if (foxP3.isBlank() && (igra == null || igra == 2) && visceralFat.isBlank()) return null
            if (isFoxP3Valid(foxP3) && igra != null && igra > 0 && igra < 2 && isVisceralFatValid(
                    visceralFat
                )
            ) return UiResource.StringResource(R.string.fill_data)
            return null
        }
    }

    object ViewAnimationUtils {
        fun expand(v: View) {
            v.measure(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            val targtetHeight: Int = v.measuredHeight
            v.layoutParams.height = 0
            v.visibility = View.VISIBLE
            val a: Animation = object : Animation() {
                override fun applyTransformation(interpolatedTime: Float, t: Transformation?) {
                    v.layoutParams.height =
                        if (interpolatedTime == 1f) ViewGroup.LayoutParams.WRAP_CONTENT else (targtetHeight * interpolatedTime).toInt()
                    v.requestLayout()
                }

                override fun willChangeBounds(): Boolean {
                    return true
                }
            }
            a.duration = (targtetHeight / v.context.resources.displayMetrics.density).toLong()
            v.startAnimation(a)
        }

        fun collapse(v: View) {
            val initialHeight: Int = v.measuredHeight
            val a: Animation = object : Animation() {
                override fun applyTransformation(interpolatedTime: Float, t: Transformation?) {
                    if (interpolatedTime == 1f) {
                        v.visibility = View.GONE
                    } else {
                        v.layoutParams.height =
                            initialHeight - (initialHeight * interpolatedTime).toInt()
                        v.requestLayout()
                    }
                }

                override fun willChangeBounds(): Boolean {
                    return true
                }
            }
            a.duration = (
                    initialHeight / v.context.resources
                        .displayMetrics.density
                    ).toLong()
            v.startAnimation(a)
        }
    }

    fun predict(
        ageAtFirstPresent: Int,
        gender: Int,
        pastHistTb: Int,
        symDurAFT: Int,
        haemoglobin: Double,
        bleedingPr: Int,
        perianalDis: Int,
        diarrhea: Int,
        pulmDis: Int,
        fever: Int,
        weightLoss: Int,
        combSign: Int,
        muralStrat: Int,
        skipLesion: Int,
        longSeg: Int,
        necroticLNodes: Int,
        anyChestImaging: Int,
        stricture: Int,
        longUlcers: Int,
        transUlcers: Int,
        apthUlcers: Int,
        cobblestoning: Int,
        rectosigmoid: Int,
        iValveInvolv: Int,
        rlColonic: Int,
        pseudopolyps: Int,
        granulomaBiopsy: Int,
        ugiInvolv: Int
    ): String {
//        192.168.1.153
        try {
            val body = "{\"ageAtFirstPresentation\":$ageAtFirstPresent,\"Gender\":$gender,\"pastHistoryOfTb\":$pastHistTb,\"SymptomsDurationAtTheTimeOfFirstVisit\":$symDurAFT,\"haemoglobin\":$haemoglobin,\"bleedingPrRectum\":$bleedingPr,\"perianalDisease\":$perianalDis,\"diarrheaMoreThan4Weeks\":$diarrhea,\"pulmonaryDisease\":$pulmDis,\"Fever\":$fever,\"significantWeightLoss\":$weightLoss,\"combSign\":$combSign,\"muralStratisfaction\":$muralStrat,\"skipLesions\":$skipLesion,\"longSegment\":$longSeg,\"necroticLymphNodes\":$necroticLNodes,\"anyChestImaging\":$anyChestImaging,\"stricture\":$stricture,\"longitudinalUlcers\":$longUlcers,\"transverseUlcers\":$transUlcers,\"apthousUlcers\":$apthUlcers,\"Cobblestoning\":$cobblestoning,\"rectosigmoidInvolvement\":$rectosigmoid,\"ileocecalValveInvolvement\":$iValveInvolv,\"rightAsWellAsLeftsidedColonicInvolvement\":$rlColonic,\"pseudopolyps\":$pseudopolyps,\"granulomaOnBiopsy\":$granulomaBiopsy,\"ugiInvolvement\":$ugiInvolv}\n    "
            println(body)
            val url = URL("http://103.25.231.28:8000/predict")
            val httpConn = url.openConnection() as HttpURLConnection
            httpConn.requestMethod = "POST"

            httpConn.setRequestProperty("Accept-Encoding", "gzip, deflate")
            httpConn.setRequestProperty("Accept-Language", "en-US,en;q=0.5")
            httpConn.setRequestProperty("Content-Type", "application/json")
            httpConn.setRequestProperty("Upgrade-Insecure-Requests", "1")

            Timber.d("Curl Command:- %s",toCurlRequest(httpConn,body))
            httpConn.doOutput = true
            val writer = OutputStreamWriter(httpConn.outputStream)
            writer.write(body)
            writer.flush()
            writer.close()
            httpConn.outputStream.close()

            var responseStream =
                if (httpConn.responseCode / 100 == 2) httpConn.inputStream else httpConn.errorStream
            if ("gzip" == httpConn.contentEncoding) {
                responseStream = GZIPInputStream(responseStream)
            }
            val s = Scanner(responseStream).useDelimiter("\\A")
            val response = if (s.hasNext()) s.next() else ""
            return response
        } catch (e: Exception) {
            e.printStackTrace()
            return "error"
        }
    }

    fun toCurlRequest(connection: HttpURLConnection, body: String?): String {
        val builder = StringBuilder("curl -v ")

        // Method
        builder.append("-X ").append(connection.requestMethod).append(" \\\n  ")

        // Headers
        for ((key, value1) in connection.requestProperties) {
            builder.append("-H \"").append(key).append(":")
            for (value in value1) builder.append(" ").append(value)
            builder.append("\" \\\n  ")
        }

        // Body
        if (body != null) builder.append("-d '").append(body).append("' \\\n  ")

        // URL
        builder.append("\"").append(connection.url).append("\"")
        return builder.toString()
    }
}
