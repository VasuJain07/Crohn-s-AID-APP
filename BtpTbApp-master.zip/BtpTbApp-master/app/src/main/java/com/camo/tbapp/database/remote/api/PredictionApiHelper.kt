package com.camo.tbapp.database.remote.api

import com.camo.tbapp.database.remote.model.PredictionInput
import retrofit2.Response
import javax.inject.Inject

class PredictionApiHelper @Inject constructor(private val apiService: ApiService) :
    ApiHelperInterface {
    override suspend fun ping() = apiService.ping()
    override suspend fun predict(predictionInput: PredictionInput): Response<Any> =
        apiService.predict(predictionInput)
}
