package com.camo.tbapp.util

object Constants {
    const val BASE_URL = "https://103.25.231.28:8000/"

    enum class SiteOfStricture(val key: Int) {
        RIGHT_COLON(1),
        LEFT_COLON(2),
        TRANS_COLON(3),
        SMALL_BOWEL(5),
        NONE(4)
    }
}
