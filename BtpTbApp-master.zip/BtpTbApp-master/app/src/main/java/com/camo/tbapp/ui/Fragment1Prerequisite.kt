package com.camo.tbapp.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import com.camo.tbapp.databinding.Fragment1PrerequisiteBinding
import com.camo.tbapp.ui.viewmodels.AddNewCaseActivityVM
import dagger.hilt.android.AndroidEntryPoint
import timber.log.Timber

@AndroidEntryPoint
class Fragment1Prerequisite : Fragment() {
    private val viewModel: AddNewCaseActivityVM by activityViewModels()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Timber.d("onCreate called")
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val binding = Fragment1PrerequisiteBinding.inflate(inflater, container, false)
        return binding.root
    }
}
