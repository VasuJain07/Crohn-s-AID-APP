package com.camo.tbapp.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.core.widget.doOnTextChanged
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import com.camo.tbapp.databinding.Fragment2BasicInfoBinding
import com.camo.tbapp.ui.viewmodels.AddNewCaseActivityVM
import timber.log.Timber
import java.util.Calendar

class Fragment2BasicInfo : Fragment() {
    private var _binding: Fragment2BasicInfoBinding? = null
    private val viewModel: AddNewCaseActivityVM by activityViewModels()

    // valid from onCreateView to onDestroy
    private val binding: Fragment2BasicInfoBinding get() = _binding!!

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Timber.d("onCreate called")
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = Fragment2BasicInfoBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.tvDate.text = Calendar.getInstance().time.toString()
        binding.tvDate.text = viewModel.date
        binding.etvUhid.setText(viewModel.uhid, TextView.BufferType.EDITABLE)
        binding.etvCity.setText(viewModel.city, TextView.BufferType.EDITABLE)
        binding.etvPatientName.setText(viewModel.patientName, TextView.BufferType.EDITABLE)
        binding.etvPhysicianName.setText(
            viewModel.physicianName,
            TextView.BufferType.EDITABLE
        )
        binding.etvPatientPhoneNumber.setText(
            viewModel.patientNumber,
            TextView.BufferType.EDITABLE
        )
        binding.etvPhysicianPhoneNumber.setText(
            viewModel.physicianNumber,
            TextView.BufferType.EDITABLE
        )

        setUpListeners()
        setDefaults()
    }

    private fun setDefaults() {
        with(binding) {
            etvUhid.setText(viewModel.uhid, TextView.BufferType.EDITABLE)
        }
    }

    private fun setUpListeners() {

        binding.etvUhid.doOnTextChanged { text, start, before, count ->
            viewModel.setUhid(text.toString())
        }
        binding.etvCity.doOnTextChanged { text, start, before, count ->
            viewModel.setCity(text.toString())
        }
        binding.etvPatientPhoneNumber.doOnTextChanged { text, start, before, count ->
            viewModel.setPatientNumber(text.toString())
        }
        binding.etvPatientName.doOnTextChanged { text, start, before, count ->
            viewModel.setPatientName(text.toString())
        }
        binding.etvPhysicianName.doOnTextChanged { text, start, before, count ->
            viewModel.setPhysicianName(text.toString())
        }
        binding.etvPhysicianPhoneNumber.doOnTextChanged { text, start, before, count ->
            viewModel.setPhysicianNumber(text.toString())
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        _binding = null
    }
}
