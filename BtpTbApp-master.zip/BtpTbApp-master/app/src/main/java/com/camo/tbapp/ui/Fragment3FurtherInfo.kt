package com.camo.tbapp.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.TextView
import androidx.core.widget.doOnTextChanged
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.lifecycleScope
import com.camo.tbapp.R
import com.camo.tbapp.databinding.Fragment3FutherInfoBinding
import com.camo.tbapp.ui.viewmodels.AddNewCaseActivityVM
import com.camo.tbapp.util.Constants
import com.camo.tbapp.util.Utility.ViewAnimationUtils.collapse
import com.camo.tbapp.util.Utility.ViewAnimationUtils.expand
import kotlinx.coroutines.flow.collect
import timber.log.Timber

class Fragment3FurtherInfo : Fragment() {
    private val viewModel by activityViewModels<AddNewCaseActivityVM>()
    private var _binding: Fragment3FutherInfoBinding? = null

    // valid from onCreateView to onDestroy
    private val binding: Fragment3FutherInfoBinding get() = _binding!!
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Timber.d("onCreate called")
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = Fragment3FutherInfoBinding.inflate(inflater, container, false)
        return binding.root
    }
    lateinit var adaAdapter: ArrayAdapter<CharSequence>

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        with(binding) {

            with(vClinicalInfo) {
                val adapter = ArrayAdapter(
                    requireContext(),
                    R.layout.support_simple_spinner_dropdown_item,
                    requireContext().resources.getTextArray(R.array.gender)
                )
                spinnerGender.setAdapter(adapter)
                etvAgeAtFPresentation.setText(
                    viewModel.ageAtPres,
                    TextView.BufferType.EDITABLE
                )
                val pos = viewModel.gender
                if (pos != null) spinnerGender.setText(
                    spinnerGender.adapter.getItem(pos).toString(), false
                )

                val pastHistTbAdapter = ArrayAdapter(
                    root.context, R.layout.support_simple_spinner_dropdown_item,
                    requireContext().resources.getTextArray(R.array.past_hist_tb)
                )
                spinnerPastHistTb.setAdapter(pastHistTbAdapter)
                val bleedingPRAdapter = ArrayAdapter(
                    root.context, R.layout.support_simple_spinner_dropdown_item,
                    requireContext().resources.getTextArray(R.array.yes_no)
                )
                spinnerBleedingPR.setAdapter(bleedingPRAdapter)
                val perianalDiseaseAdapter = ArrayAdapter(
                    root.context, R.layout.support_simple_spinner_dropdown_item,
                    requireContext().resources.getTextArray(R.array.yes_no)
                )
                spinnerPerianalDis.setAdapter(perianalDiseaseAdapter)
                val diarrheaAdapter = ArrayAdapter(
                    root.context, R.layout.support_simple_spinner_dropdown_item,
                    requireContext().resources.getTextArray(R.array.yes_no)
                )
                spinnerDiaMoreThan4Weeks.setAdapter(diarrheaAdapter)
                val pulSymptomsAdapter = ArrayAdapter(
                    root.context, R.layout.support_simple_spinner_dropdown_item,
                    requireContext().resources.getTextArray(R.array.yes_no)
                )
                spinnerPulmSymptoms.setAdapter(pulSymptomsAdapter)
                val feverAdapter = ArrayAdapter(
                    root.context, R.layout.support_simple_spinner_dropdown_item,
                    requireContext().resources.getTextArray(R.array.yes_no)
                )
                spinnerFever.setAdapter(feverAdapter)
                val signWeightLossAdapter = ArrayAdapter(
                    root.context, R.layout.support_simple_spinner_dropdown_item,
                    requireContext().resources.getTextArray(R.array.yes_no)
                )
                spinnerSigWeightLoss.setAdapter(signWeightLossAdapter)
            }
            adaAdapter = ArrayAdapter(
                root.context, R.layout.support_simple_spinner_dropdown_item,
                requireContext().resources.getTextArray(R.array.ada_array)
            )
            with(vImaging) {
                val combAdapter = ArrayAdapter(
                    root.context, R.layout.support_simple_spinner_dropdown_item,
                    requireContext().resources.getTextArray(R.array.yes_no)
                )
                spinnerCombSign.setAdapter(combAdapter)
                val muralStratAdapter = ArrayAdapter(
                    root.context, R.layout.support_simple_spinner_dropdown_item,
                    requireContext().resources.getTextArray(R.array.yes_no)
                )
                spinnerMuralSTSign.setAdapter(muralStratAdapter)
                val skipLesionAdapter = ArrayAdapter(
                    root.context, R.layout.support_simple_spinner_dropdown_item,
                    requireContext().resources.getTextArray(R.array.yes_no)
                )
                spinnerSkipLesion.setAdapter(skipLesionAdapter)
                val longSegAdapter = ArrayAdapter(
                    root.context, R.layout.support_simple_spinner_dropdown_item,
                    requireContext().resources.getTextArray(R.array.yes_no)
                )
                spinnerLongSeg.setAdapter(longSegAdapter)
                val necroticLymphAdapter = ArrayAdapter(
                    root.context, R.layout.support_simple_spinner_dropdown_item,
                    requireContext().resources.getTextArray(R.array.yes_no)
                )
                spinnerNecroticLymphNodes.setAdapter(necroticLymphAdapter)
                val chestImagingAdapter = ArrayAdapter(
                    root.context, R.layout.support_simple_spinner_dropdown_item,
                    requireContext().resources.getTextArray(R.array.chest_imaging)
                )
                spinnerAnyChestImaging.setAdapter(chestImagingAdapter)
                val strictureAdapter = ArrayAdapter(
                    root.context, R.layout.support_simple_spinner_dropdown_item,
                    requireContext().resources.getTextArray(R.array.yes_no)
                )
                spinnerStricture.setAdapter(strictureAdapter)
                val ascitiesAdapter = ArrayAdapter(
                    root.context, R.layout.support_simple_spinner_dropdown_item,
                    requireContext().resources.getTextArray(R.array.pres_absent)
                )
                spinnerAscites.setAdapter(ascitiesAdapter)
                spinnerAda.setAdapter(adaAdapter)
            }
            with(vColonoscopy) {
                val longUlcersAdapter = ArrayAdapter(
                    root.context, R.layout.support_simple_spinner_dropdown_item,
                    requireContext().resources.getTextArray(R.array.yes_no)
                )
                spinnerLongUlcers.setAdapter(longUlcersAdapter)
                val unknownUlcersAdapter = ArrayAdapter(
                    root.context, R.layout.support_simple_spinner_dropdown_item,
                    requireContext().resources.getTextArray(R.array.yes_no)
                )
                spinnerUnknownTypOfUlcers.setAdapter(unknownUlcersAdapter)
                val transverseUlcersAdapter = ArrayAdapter(
                    root.context, R.layout.support_simple_spinner_dropdown_item,
                    requireContext().resources.getTextArray(R.array.yes_no)
                )
                spinnerTransversesUlc.setAdapter(transverseUlcersAdapter)
                val apthousAdapter = ArrayAdapter(
                    root.context, R.layout.support_simple_spinner_dropdown_item,
                    requireContext().resources.getTextArray(R.array.yes_no)
                )
                spinnerApthUlcers.setAdapter(apthousAdapter)
                val cobblestoningAdapter = ArrayAdapter(
                    root.context, R.layout.support_simple_spinner_dropdown_item,
                    requireContext().resources.getTextArray(R.array.yes_no)
                )
                spinnerCobblestoning.setAdapter(cobblestoningAdapter)
                val rectoInvolvementAdapter = ArrayAdapter(
                    root.context, R.layout.support_simple_spinner_dropdown_item,
                    requireContext().resources.getTextArray(R.array.yes_no)
                )
                spinnerRectoInvolvement.setAdapter(rectoInvolvementAdapter)
                val iValveInvolvementAdapter = ArrayAdapter(
                    root.context, R.layout.support_simple_spinner_dropdown_item,
                    requireContext().resources.getTextArray(R.array.yes_no)
                )
                spinnerIValveInvolvement.setAdapter(iValveInvolvementAdapter)
                val rlSidedColonicInvlovementAdapter = ArrayAdapter(
                    root.context, R.layout.support_simple_spinner_dropdown_item,
                    requireContext().resources.getTextArray(R.array.ic_involvement)
                )
                spinnerRLColonicInvolvement.setAdapter(rlSidedColonicInvlovementAdapter)
                val pseudopolypsAdapter = ArrayAdapter(
                    root.context, R.layout.support_simple_spinner_dropdown_item,
                    requireContext().resources.getTextArray(R.array.yes_no)
                )
                spinnerPseudopolyps.setAdapter(pseudopolypsAdapter)
            }
            with(vMisc) {
                val mantouxAdapter = ArrayAdapter(
                    root.context, R.layout.support_simple_spinner_dropdown_item,
                    requireContext().resources.getTextArray(R.array.pos_neg)
                )
                spinnerMantoux.setAdapter(mantouxAdapter)
                val granulomaBiopsyAdapter = ArrayAdapter(
                    root.context, R.layout.support_simple_spinner_dropdown_item,
                    requireContext().resources.getTextArray(R.array.granuloma_biopsy)
                )
                spinnerGranulomaOnBiopsy.setAdapter(granulomaBiopsyAdapter)
                spinnerUgiInvolvement.setAdapter(
                    ArrayAdapter(
                        requireContext(),
                        R.layout.support_simple_spinner_dropdown_item,
                        requireContext().resources.getTextArray(R.array.ugi_involvement)
                    )
                )
            }
        }
        setUpListeners()
    }

    private fun setUpListeners() {
        with(binding.vClinicalInfo) {
            spinnerGender.onItemClickListener =
                AdapterView.OnItemClickListener { parent, view, position, id ->
                    viewModel.setGender(position)
                }
            etvAgeAtFPresentation.doOnTextChanged { text, start, before, count ->
                viewModel.setAgeAtFPres(text.toString())
            }
            spinnerPastHistTb.onItemClickListener =
                AdapterView.OnItemClickListener { parent, view, position, id ->
                    viewModel.setPastHistOfTb(position)
                }
            spinnerSigWeightLoss.onItemClickListener =
                AdapterView.OnItemClickListener { parent, view, position, id ->
                    viewModel.setSigWeightLoss(position)
                }
            spinnerFever.onItemClickListener =
                AdapterView.OnItemClickListener { parent, view, position, id ->
                    viewModel.setFever(position)
                }
            spinnerPulmSymptoms.onItemClickListener =
                AdapterView.OnItemClickListener { parent, view, position, id ->
                    viewModel.setPulmSymptoms(position)
                }
            spinnerDiaMoreThan4Weeks.onItemClickListener =
                AdapterView.OnItemClickListener { parent, view, position, id ->
                    viewModel.setDiarrhea(position)
                }
            spinnerPerianalDis.onItemClickListener =
                AdapterView.OnItemClickListener { parent, view, position, id ->
                    viewModel.setPerianalDisease(position)
                }
            spinnerBleedingPR.onItemClickListener =
                AdapterView.OnItemClickListener { parent, view, position, id ->
                    viewModel.setBleedingPR(position)
                }
        }
        binding.tvClinicalInfo.setOnClickListener {
            viewModel.setSection(AddNewCaseActivityVM.Companion.FurtherInfoSections.CLINICAL_INFO)
        }
        binding.tvImaging.setOnClickListener {
            viewModel.setSection(AddNewCaseActivityVM.Companion.FurtherInfoSections.IMAGING)
        }
        binding.tvColonoscopy.setOnClickListener {
            viewModel.setSection(AddNewCaseActivityVM.Companion.FurtherInfoSections.COLONOSCOPY)
        }
        binding.tvMisc.setOnClickListener {
            viewModel.setSection(AddNewCaseActivityVM.Companion.FurtherInfoSections.MISC)
        }
        with(binding.vClinicalInfo) {
            ivpastHistTb.setOnClickListener {
                viewModel.explain(requireContext().resources.getString(R.string.past_hist_tb))
            }
            ivPerianalDis.setOnClickListener {
                viewModel.explain(requireContext().resources.getString(R.string.perianal_disease))
            }
            ivPulmSymptoms.setOnClickListener {
                viewModel.explain(requireContext().resources.getString(R.string.pulmonary_symptoms))
            }
            ivSigWeightLoss.setOnClickListener {
                viewModel.explain(requireContext().resources.getString(R.string.sig_weight_loss))
            }
            etvSymptomDurationAtTimeFV.doOnTextChanged { text, start, before, count ->
                viewModel.setDurationAtTimeFV((text ?: "").toString())
            }
        }
        with(binding.vColonoscopy) {
//            if(viewModel.pseudopolyps !=null) spinnerPseudopolyps.setSelection(viewModel.pseudopolyps!!)
            spinnerPseudopolyps.onItemClickListener =
                AdapterView.OnItemClickListener { parent, view, position, id ->
                    viewModel.setPseudoPolyps(position)
                }
            spinnerRLColonicInvolvement.onItemClickListener =
                AdapterView.OnItemClickListener { parent, view, position, id ->
                    viewModel.setRLColonicI(position)
                }
            spinnerIValveInvolvement.onItemClickListener =
                AdapterView.OnItemClickListener { parent, view, position, id ->
                    viewModel.setIValveInvolvement(position)
                }
            spinnerRectoInvolvement.onItemClickListener =
                AdapterView.OnItemClickListener { parent, view, position, id ->
                    viewModel.setRectoInvolvement(position)
                }
            spinnerCobblestoning.onItemClickListener =
                AdapterView.OnItemClickListener { parent, view, position, id ->
                    viewModel.setCobblestoning(position)
                }
            spinnerApthUlcers.onItemClickListener =
                AdapterView.OnItemClickListener { parent, view, position, id ->
                    viewModel.setApthUlcers(position)
                }
            spinnerTransversesUlc.onItemClickListener =
                AdapterView.OnItemClickListener { parent, view, position, id ->
                    viewModel.setTransverseUlc(position)
                }
            spinnerLongUlcers.onItemClickListener =
                AdapterView.OnItemClickListener { parent, view, position, id ->
                    viewModel.setLongUlcers(position)
                }
            spinnerUnknownTypOfUlcers.onItemClickListener =
                AdapterView.OnItemClickListener { parent, view, position, id ->
                    viewModel.setUnkTypeUlcers(position)
                }
        }
        with(binding.vColonoscopy) {
            ivLongUlcers.setOnClickListener {
                viewModel.explain(requireContext().resources.getString(R.string.long_ulcers))
            }
            ivUnkTypeUlcers.setOnClickListener {
                viewModel.explain(requireContext().resources.getString(R.string.unk_typ_ulcers))
            }
            ivTransUlcers.setOnClickListener {
                viewModel.explain(requireContext().resources.getString(R.string.trans_ulcers))
            }
            ivApthousUlcers.setOnClickListener {
                viewModel.explain(requireContext().resources.getString(R.string.apthous_ulcers))
            }
            ivCobblestoning.setOnClickListener {
                viewModel.explain(requireContext().resources.getString(R.string.cobblestoning))
            }
            ivPseudopolyps.setOnClickListener {
                viewModel.explain(requireContext().resources.getString(R.string.pseudopolyps))
            }
        }
        with(binding.vImaging) {
            ivCombSign.setOnClickListener {
                viewModel.explain(requireContext().resources.getString(R.string.comb_sign))
            }
            ivMuralStrat.setOnClickListener {
                viewModel.explain(requireContext().resources.getString(R.string.mural_strat_target_sign))
            }
            ivChestImaging.setOnClickListener {
                viewModel.explain(requireContext().resources.getString(R.string.any_chest_imaging))
            }
            ivStricture.setOnClickListener {
                viewModel.explain(requireContext().resources.getString(R.string.stricture))
            }
            ivSkipLesion.setOnClickListener {
                viewModel.explain(requireContext().resources.getString(R.string.skip_lesi_more_than_3))
            }
            ivSiteOfStricture.setOnClickListener {
                viewModel.explain(requireContext().resources.getString(R.string.stricture))
            }
            spinnerAda.onItemClickListener =
                AdapterView.OnItemClickListener { parent, view, position, id ->
                    viewModel.setAda(position)
                }
            spinnerAnyChestImaging.onItemClickListener =
                AdapterView.OnItemClickListener { parent, view, position, id ->
                    viewModel.setAnyChestImaging(position)
                }
            spinnerAscites.onItemClickListener =
                AdapterView.OnItemClickListener { parent, view, position, id ->
                    viewModel.setAscites(position)
                    if(position == 0){
                        tilADA.visibility = View.VISIBLE
                    }else{
//                        if absent automatically set to not tapped
                        viewModel.setAda(2)
                        spinnerAda.setText(adaAdapter.getItem(2),false)
                        tilADA.visibility = View.GONE
                    }
                }
            spinnerCombSign.onItemClickListener =
                AdapterView.OnItemClickListener { parent, view, position, id ->
                    viewModel.setCombSign(position)
                }
            spinnerLongSeg.onItemClickListener =
                AdapterView.OnItemClickListener { parent, view, position, id ->
                    viewModel.setLongSeg(position)
                }
            spinnerMuralSTSign.onItemClickListener =
                AdapterView.OnItemClickListener { parent, view, position, id ->
                    viewModel.setMuralSTSign(position)
                }
            spinnerNecroticLymphNodes.onItemClickListener =
                AdapterView.OnItemClickListener { parent, view, position, id ->
                    viewModel.setNecroticLymphNodes(position)
                }
            spinnerSkipLesion.onItemClickListener =
                AdapterView.OnItemClickListener { parent, view, position, id ->
                    viewModel.setSkipLesion(position)
                }
            spinnerStricture.onItemClickListener =
                AdapterView.OnItemClickListener { parent, view, position, id ->
                    viewModel.setStricture(position)
                    // if position is for No we hide site of stricture
                    if (position == 0) {
                        llSiteStrictureOptions.visibility = View.VISIBLE
                        cbYTranColon.visibility = View.VISIBLE
                        cbYLeftColon.visibility = View.VISIBLE
                        cbSmallBowel.visibility = View.VISIBLE
                        cbYrightColon.visibility = View.VISIBLE
//                        TODO place these in group
//                        grpAscitesSite.visibility = ViewGroup.VISIBLE
                    } else {
                        llSiteStrictureOptions.visibility = View.GONE
                        cbYTranColon.visibility = View.GONE
                        cbYLeftColon.visibility = View.GONE
                        cbSmallBowel.visibility = View.GONE
                        cbYrightColon.visibility = View.GONE

//                        unselect all the checkboxes because stricture not present
                        cbYTranColon.isChecked = false
                        cbYLeftColon.isChecked = false
                        cbSmallBowel.isChecked = false
                        cbYrightColon.isChecked = false

//                        grpAscitesSite.visibility = ViewGroup.GONE
                    }
                }
            cbSmallBowel.setOnCheckedChangeListener { compoundButton, b ->
                viewModel.addSiteOfStricture(Constants.SiteOfStricture.SMALL_BOWEL, b)
            }
            cbYLeftColon.setOnCheckedChangeListener { compoundButton, b ->
                viewModel.addSiteOfStricture(Constants.SiteOfStricture.LEFT_COLON, b)
            }
            cbYTranColon.setOnCheckedChangeListener { compoundButton, b ->
                viewModel.addSiteOfStricture(Constants.SiteOfStricture.TRANS_COLON, b)
            }
            cbYrightColon.setOnCheckedChangeListener { compoundButton, b ->
                viewModel.addSiteOfStricture(Constants.SiteOfStricture.RIGHT_COLON, b)
            }
        }
        with(binding.vMisc) {
            spinnerGranulomaOnBiopsy.onItemClickListener =
                AdapterView.OnItemClickListener { parent, view, position, id ->
                    viewModel.setGranulomaOnBiopsy(position)
                }
            spinnerMantoux.onItemClickListener =
                AdapterView.OnItemClickListener { parent, view, position, id ->
                    viewModel.setMantoux(position)
                }
            etvAlbumin.doOnTextChanged { text, start, before, count ->
                viewModel.setAlbumin((text ?: "").toString())
            }
            etvHemoglobin.doOnTextChanged { text, start, before, count ->
                viewModel.setHaemoglobin((text ?: "").toString())
            }
            etvGlobulin.doOnTextChanged { text, start, before, count ->
                viewModel.setGlobulin((text ?: "").toString())
            }
            spinnerUgiInvolvement.onItemClickListener =
                AdapterView.OnItemClickListener { parent, view, position, id ->
                    viewModel.setUgiInvolvement(position)
                }
        }
        lifecycleScope.launchWhenStarted {
            viewModel.expandedSection.collect {
                Timber.d("$it info clicked")
                when (it) {
                    AddNewCaseActivityVM.Companion.FurtherInfoSections.CLINICAL_INFO -> {
                        expand(binding.vClinicalInfo.root)
                        collapse(binding.vImaging.root)
                        collapse(binding.vColonoscopy.root)
                        collapse(binding.vMisc.root)
                    }
                    AddNewCaseActivityVM.Companion.FurtherInfoSections.IMAGING -> {
                        collapse(binding.vClinicalInfo.root)
                        expand(binding.vImaging.root)
                        collapse(binding.vColonoscopy.root)
                        collapse(binding.vMisc.root)
                    }
                    AddNewCaseActivityVM.Companion.FurtherInfoSections.COLONOSCOPY -> {
                        collapse(binding.vClinicalInfo.root)
                        collapse(binding.vImaging.root)
                        expand(binding.vColonoscopy.root)
                        collapse(binding.vMisc.root)
                    }
                    AddNewCaseActivityVM.Companion.FurtherInfoSections.MISC -> {
                        collapse(binding.vClinicalInfo.root)
                        collapse(binding.vImaging.root)
                        collapse(binding.vColonoscopy.root)
                        expand(binding.vMisc.root)
                    }
                    AddNewCaseActivityVM.Companion.FurtherInfoSections.NONE -> {
                        collapse(binding.vClinicalInfo.root)
                        collapse(binding.vImaging.root)
                        collapse(binding.vColonoscopy.root)
                        collapse(binding.vMisc.root)
                    }
                }
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        _binding = null
    }
}
