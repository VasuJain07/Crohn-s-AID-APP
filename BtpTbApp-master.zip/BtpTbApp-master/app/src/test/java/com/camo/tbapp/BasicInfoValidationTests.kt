package com.camo.tbapp

import com.camo.tbapp.util.Utility.ValidationLogic.isHaemoglobinValid
import com.camo.tbapp.util.Utility.ValidationLogic.isNameValid
import com.camo.tbapp.util.Utility.ValidationLogic.validateBasicInfo
import com.camo.tbapp.util.Utility.predict
import com.google.gson.JsonObject
import com.google.gson.JsonParser
import org.junit.Assert.assertEquals
import org.junit.Test
import java.io.InputStream
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import java.util.*
import java.util.zip.GZIPInputStream


/**
 * Example local unit test, which will execute on the development machine (host).
 *
 * See [testing documentation](http://d.android.com/tools/testing).
 */
class BasicInfoValidationTests {
    @Test
    fun isNameValidationCorrect() {
        val validNames = listOf("sa", "sa sa", "saurav", "saurav rao", "saurav rao test")
        for (x in validNames) {
            print(x)
            assertEquals(true, isNameValid(x))
        }
        val invalidNames = listOf("", ".", "....  .", "     ")
        for (x in invalidNames) {
            print(x)
            assertEquals(false, isNameValid(x))
        }
    }
    @Test
    fun isBasicInfoValid() {
        val a = validateBasicInfo("", "", "", "", "", "")
        assertEquals(a, false)
    }
    @Test
    fun test() {
        println(
            predict(
                1,
                1,
                1,
                1,
                1.0,
                1,
                1,
                1,
                1,
                1,
                1,
                1,
                1,
                1,
                1,
                1,
                1,
                1,
                1,
                1,
                1,
                1,
                1,
                1,
                1,
                1,
                1,
                1
            )
        )
    }

    @Test
    fun test2() {
        val x = "[{\"TB\":0.4634,\"UC\":0.5366}]"
        val xx = x.substring(1, x.length - 1)
        val y: JsonObject = JsonParser().parse(xx).asJsonObject
        println("hiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii$y")
    }

    @Test
    fun testHaemoglobinValidation(){
        val h = ""
        assert(!isHaemoglobinValid(h))
    }

    @Test
    fun xyz(){
        val url = URL("http://103.25.231.28:8000/predict")
        val httpConn: HttpURLConnection = url.openConnection() as HttpURLConnection
        httpConn.setRequestMethod("POST")

        httpConn.setRequestProperty("Accept-Encoding", "gzip, deflate")
        httpConn.setRequestProperty("Accept-Language", "en-US,en;q=0.5")
        httpConn.setRequestProperty("Content-Type", "application/json")
        httpConn.setRequestProperty("Upgrade-Insecure-Requests", "1")

        httpConn.setDoOutput(true)
        val writer = OutputStreamWriter(httpConn.getOutputStream())
        writer.write("{\"ageAtFirstPresentation\":10,\"Gender\":3,\"pastHistoryOfTb\":1,\"SymptomsDurationAtTheTimeOfFirstVisit\":1,\"haemoglobin\":10.0,\"bleedingPrRectum\":1,\"perianalDisease\":1,\"diarrheaMoreThan4Weeks\":1,\"pulmonaryDisease\":1,\"Fever\":1,\"significantWeightLoss\":1,\"combSign\":1,\"muralStratisfaction\":1,\"skipLesions\":1,\"longSegment\":1,\"necroticLymphNodes\":1,\"anyChestImaging\":5,\"stricture\":1,\"longitudinalUlcers\":1,\"transverseUlcers\":1,\"apthousUlcers\":1,\"Cobblestoning\":1,\"rectosigmoidInvolvement\":1,\"ileocecalValveInvolvement\":1,\"rightAsWellAsLeftsidedColonicInvolvement\":1,\"pseudopolyps\":1,\"granulomaOnBiopsy\":6,\"ugiInvolvement\":2}\n    ")
        writer.flush()
        writer.close()
        httpConn.getOutputStream().close()

        var responseStream: InputStream? =
            if (httpConn.getResponseCode() / 100 === 2) httpConn.getInputStream() else httpConn.getErrorStream()
        if ("gzip" == httpConn.getContentEncoding()) {
            responseStream = GZIPInputStream(responseStream)
        }
        val s: Scanner = Scanner(responseStream).useDelimiter("\\A")
        val response = if (s.hasNext()) s.next() else ""
        println(response)
    }
}
